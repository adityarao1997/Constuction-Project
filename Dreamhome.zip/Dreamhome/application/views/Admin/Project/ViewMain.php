<!-- Begin Page Content -->
<?php echo form_open_multipart('Dashboard/Add_Portfolio/'.$cont['id'],array("class"=>"form-horizontal"));?>

<?php
$img = explode('_-_', $cont['images']);
?>


        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">View Project</h1>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url('Dashboard');?>">Home</a></li>
                <li class="breadcrumb-item active">Project Detail</li>
              </ol>
            </nav>
          </div>
          <div class="container-fluid">
            <div class="card o-hidden border-0 shadow-lg my-3">
                <div class="card-body p-0">
                  <div class="card shadow mb-4">
                    <div class="card-header py-3">
                      <center><span class="error_form_msg"></span></center>
                       </i><a class="float-right" href="<?php echo base_url('Dashboard/Portfolio');?>"><i class=" text-danger"><b>X<b></i></a> <br><br>
                        <b class="float-left  text-danger"><h4>View Project(Portfolio)</h4></b><br><hr>
                    <?php   
                      $i=0;
                      foreach ($img as $key) {
                        ?>
                        <div class="col-sm-3 float-left all_pics pic_div_<?=$i ?>">
                          <a href="../../../../Dreamhome/upload/Project/<?php echo $key;?>" target="_blank"><img target="_blank" src="../../../../Dreamhome/upload/Project/<?php echo $key;?>" class="img-fluid"/></a>
                        </div>
                        <?php
                        $i++;
                      }
                      ?>
                      <div class="row col-lg-12">
                        <div class="col-lg-6 float-right">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>City</label>
                           <input  type="text" name="city" class="form-control" id="city" placeholder="City.." value="<?=$cont['city'];?>" >
                        </div>
                      </div>
                      <div class="row col-lg-12 mt-3">
                        <div class="col-lg-12 float-left">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>Title</label>
                          <input  type="text" name="title" class="form-control " id="title" placeholder="Title" value="<?=$cont['title'];?>">
                        </div>
                        <div class="col-lg-12 float-left">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>Address</label>
                          <input  type="text" name="address" class="form-control " id="address" placeholder="Address" value="<?=$cont['address'];?>">
                        </div>
                        <div class="col-lg-12 float-left">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>Description</label>
                          <textarea  type="date" name="description" class="form-control" id="description" rows="4" placeholder="Description"><?=$cont['description'];?></textarea>
                        </div>
                      </div>
                      <div class="row col-lg-12 mt-3">
                        <div class="col-lg-6 float-left">
                           <label class="col-form-label float-left"><span class="text-danger">*</span>Builder Contact</label>
                           <input  type="text" name="builder_cont" class="form-control" id="builder_cont" placeholder="Builder Contact" value="<?=$cont['builder_cont'];?>" >
                        </div>
                        <div class="col-lg-6 float-right">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>Builder Email</label>
                           <input  type="text" name="builder_email" class="form-control" id="builder_email" placeholder="Builder Email" value="<?=$cont['builder_email'];?>">
                        </div>
                      </div>
                      
                       <div class="row mt-4">
                        <div class="col-md-6 mt-4">
                             <a class="btn btn-danger" href="<?php echo base_url('Dashboard/Portfolio');?>">Cancel</a>
                        </div>
                      </div>


                    </div>
                  </div>
                </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>

<?php echo form_close(); ?>
