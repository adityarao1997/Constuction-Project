<!-- Begin Page Content -->
<?php echo form_open_multipart('Dashboard/Add_Portfolio',array("class"=>"form-horizontal")); ?>


        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Add Project</h1>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url('Dashboard');?>">Home</a></li>
                <li class="breadcrumb-item active">Project Detail</li>
              </ol>
            </nav>
          </div>
          <div class="container-fluid">
            <div class="card o-hidden border-0 shadow-lg my-3">
                <div class="card-body p-0">
                  <div class="card shadow mb-4">
                    <div class="card-header py-3">
                      <center><span class="error_form_msg"></span></center>
                       </i><a class="float-right" href="<?php echo base_url('Dashboard/Portfolio');?>"><i class=" text-danger"><b>X<b></i></a> <br><br>
                        <b class="float-left  text-danger"><h4>Add Project(Portfolio)</h4></b><br><hr>

                      <div class="row col-lg-12">
                        <div class="col-lg-6 float-left">
                           <label class="col-form-label float-left"><span class="text-danger">*</span>Images(2 pic only)</label>
                           <input  type="file" name="images[]" class="form-control" id="images" multiple="multiple">
                        </div>
                        <div class="col-lg-6 float-right">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>City</label>
                           <input  type="text" name="city" class="form-control" id="city" placeholder="City.." multiple>
                        </div>
                      </div>
                      <div class="row col-lg-12 mt-3">
                        <div class="col-lg-12 float-left">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>Title</label>
                          <input  type="text" name="title" class="form-control " id="title" placeholder="Title">
                        </div>
                        <div class="col-lg-12 float-left">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>Address</label>
                          <input  type="text" name="address" class="form-control " id="address" placeholder="Address">
                        </div>
                        <div class="col-lg-12 float-left">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>Description</label>
                          <textarea  type="date" name="description" class="form-control" id="description" rows="4" placeholder="Description"></textarea>
                        </div>
                      </div>
                      <div class="row col-lg-12 mt-3">
                        <div class="col-lg-6 float-left">
                           <label class="col-form-label float-left"><span class="text-danger">*</span>Builder Contact</label>
                           <input  type="text" name="builder_cont" class="form-control" id="builder_cont" placeholder="Builder Contact" >
                        </div>
                        <div class="col-lg-6 float-right">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>Builder Email</label>
                           <input  type="text" name="builder_email" class="form-control" id="builder_email" placeholder="Builder Email" >
                        </div>
                      </div>
                      <div class="col-lg-12 float-left">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>iframe (Google Map)</label>
                          <textarea  type="date" name="iframe" class="form-control" id="iframe" rows="4" placeholder="Description"></textarea>
                        </div>
                      <div class="row mt-3">
                       <div class="col-lg-8">
                        <table class="table table-hover table-active" id="dynamic_field">  
                          <thead class="f1">
                          <tr>
                            <th scope="col" class="f2">Available</th>
                          </tr>
                        </thead>
                        <tbody class="thead-light">
                          <tr class="alltrs">
                            <td><input type="text" class="form-control" name="availabe[][availabe]" placeholder="Available"></td>
                            <td><button type="button" name="add" id="add" class="btn btn-success">Add</button></td> 
                          </tr>
                        </tbody>
                        </table>
                        </div>
                      </div>
                      
                       <div class="row mt-4">
                        <div class="col-md-6 mt-4">
                            <input type="submit" name="upload" class="btn btn-success" value="Save">
                             <a class="btn btn-danger" href="<?php echo base_url('Dashboard/Portfolio');?>">Cancel</a>
                        </div>
                      </div>


                    </div>
                  </div>
                </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>

<?php echo form_close(); ?>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<script type="text/javascript">
    $(document).ready(function(){      
      var i=1;  


      $('#add').click(function(){  
           i++;
           var count = $('.alltrs').length;
           count++; 
           $('#dynamic_field').append('<tr id="row'+i+'" class="dynamic-added alltrs"><td><input type="text" class="form-control " name = "availabe[][availabe]" placeholder="Member Name" /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');  
      });
    
      $(document).on('click', '.btn_remove', function(){  
           var button_id = $(this).attr("id");   
           $('#row'+button_id+'').remove();  
      });  


    });  
</script>
