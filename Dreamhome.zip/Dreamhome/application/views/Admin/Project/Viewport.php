<?php 
    $this->load->view('Admin/Layout/header');
    $this->load->view('Admin/Project/Viewport_main.php');
    $this->load->view('Admin/Layout/footer');
?>