<!-- Begin Page Content -->
<?php echo form_open('Dashboard/Contact_dt_view/'.$cont['id'],array("class"=>"form-horizontal")); ?>

        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Contact Us Detail</h1>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url('Dashboard');?>">Home</a></li>
                <li class="breadcrumb-item active">View Lead</li>
              </ol>
            </nav>
          </div>


          <div class="container-fluid">
            <div class="card o-hidden border-0 shadow-lg my-3">
                <div class="card-body p-0">
                  <div class="card shadow mb-4">
                    <div class="card-header py-3">
                      <center><span class="error_form_msg"></span></center>
                       </i><a class="float-right" href="<?php echo base_url('Dashboard/Contact_dt');?>"><i class=" text-danger"><b>X<b></i></a> <br><br>
                        <b class="float-left  text-danger"><h4>Lead Details</h4></b><br><hr>

                      <div class="row col-lg-12">
                        <div class="col-lg-6 float-left">
                           <label class="col-form-label float-left"><span class="text-danger">*</span>Name</label>
                           <input  type="text" name="name" class="form-control inpreq" id="name" placeholder="Name" value="<?php echo ($this->input->post('name') ? $this->input->post('name') : $cont['name']); ?>">
                        </div>
                        <div class="col-lg-6 float-right">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>Email</label>
                           <input  type="text" name="email" class="form-control inpreq" id="email" placeholder="Email" value="<?php echo ($this->input->post('email') ? $this->input->post('email') : $cont['email']); ?>">
                        </div>
                      </div>
                      <div class="row col-lg-12 mt-3">
                        <div class="col-lg-6 float-left">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>Mobile Number</label>
                          <input  type="text" name="mobile" class="form-control validateNumber inpreq" id="mobile" placeholder="Mobile Number." value="<?php echo ($this->input->post('mobile') ? $this->input->post('mobile') : $cont['mobile']); ?>" maxlength="10">
                        </div>
                        <div class="col-lg-6 float-right">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>Date</label>
                          <input  type="text" name="city" class="form-control inpreq" value="<?php echo ($this->input->post('crate_dt') ? $this->input->post('crate_dt') : $cont['crate_dt']); ?>" id="city" placeholder="date" >
                        </div>
                      </div>
                      <div class="row col-lg-12 mt-3">
                        <div class="col-lg-12">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>Description</label>
                          <textarea class="form-control" rows="4"><?=$cont['description']?></textarea> 
                        </div>
                       
                      </div>
                     
                     
                       <div class="row mt-4">
                        <div class="col-md-6 mt-4"><a class="btn btn-danger" href="<?php echo base_url('Dashboard/Contact_dt');?>">Cancel</a>
                        </div>
                      </div>


                    </div>
                  </div>
                </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>

<?php echo form_close(); ?>
