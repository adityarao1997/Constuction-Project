<?php 
    $this->load->view('Admin/Layout/header');
    $this->load->view('Admin/contact/View_Main.php');
    $this->load->view('Admin/Layout/footer');
?>