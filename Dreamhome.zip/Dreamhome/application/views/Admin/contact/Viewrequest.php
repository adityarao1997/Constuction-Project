<?php 
    $this->load->view('Admin/Layout/header');
    $this->load->view('Admin/contact/Viewrequest_main.php');
    $this->load->view('Admin/Layout/footer');
?>