<!-- Begin Page Content -->
<?php echo form_open_multipart('Dashboard/Banner_view/'.$ban_post['id'],array("class"=>"form-horizontal"));?>

<?php
$img = explode('_-_', $ban_post['images']);
?>


        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">View Project</h1>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url('Dashboard');?>">Home</a></li>
                <li class="breadcrumb-item active">Project Detail</li>
              </ol>
            </nav>
          </div>
          <div class="container-fluid">
            <div class="card o-hidden border-0 shadow-lg my-3">
                <div class="card-body p-0">
                  <div class="card shadow mb-4">
                    <div class="card-header py-3">
                      <center><span class="error_form_msg"></span></center>
                       </i><a class="float-right" href="<?php echo base_url('Dashboard/Banner');?>"><i class=" text-danger"><b>X<b></i></a> <br><br>
                        <b class="float-left  text-danger"><h4>View Project(Portfolio)</h4></b><br><hr>
                    
                      <div class="row col-lg-12">
                        <div class="col-lg-12 float-right">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>Title</label>
                           <input  type="text" name="city" class="form-control" id="city" placeholder="Title.." value="<?=$ban_post['title'];?>" >
                        </div>
                      </div>
                    <?php   
                      $i=0;
                      foreach ($img as $key) {
                        ?>
                        <div class="col-sm-3 mt-4 float-left all_pics pic_div_<?=$i ?>">
                          <a href="../../../../Dreamhome/upload/Banner/<?php echo $key;?>" target="_blank"><img target="_blank" src="../../../../Dreamhome/upload/Banner/<?php echo $key;?>" class="img-fluid"/></a>
                        </div>
                        <?php
                        $i++;
                      }
                      ?>
                     
                       <div class="row mt-4">
                        <div class="col-md-6 mt-4">
                             <a class="btn btn-danger" href="<?php echo base_url('Dashboard/Banner');?>">Cancel</a>
                        </div>
                      </div>


                    </div>
                  </div>
                </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>

<?php echo form_close(); ?>
