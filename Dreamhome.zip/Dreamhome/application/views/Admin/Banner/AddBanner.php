<?php 
    $this->load->view('Admin/Layout/header');
    $this->load->view('Admin/Banner/AddBanner_Main.php');
    $this->load->view('Admin/Layout/footer');
?>






