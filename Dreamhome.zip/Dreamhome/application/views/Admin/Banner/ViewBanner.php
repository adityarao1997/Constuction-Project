<?php 
    $this->load->view('Admin/Layout/header');
    $this->load->view('Admin/Banner/ViewBanner_main.php');
    $this->load->view('Admin/Layout/footer');
?>