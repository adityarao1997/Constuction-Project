<!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Project Portfolio</h1>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url('Dashboard');?>">Home</a></li>
                <li class="breadcrumb-item active">All Protfolio</li>
              </ol>
            </nav>
          </div>


          <div class="container-fluid">
            <div class="card o-hidden border-0 shadow-lg my-3">
                <div class="card-body p-0">
                  <div class="card shadow mb-4">
                    <div class="card-header py-3">
                      <div class="row col-lg-12">
                         <a href="<?php echo base_url('Dashboard/Add_Banner');?>" class="btn btn-primary btn-sm m-4">Banner  <i class="fas fa-user-plus"></i></a> 
                          <div class="table-responsive">
                              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                  <tr>
                                    <th>Sno.</th>
                                    <th>image</th>
                                    <th>Title</th>
                                    <th>Action</th>
                                  </tr>
                                  </thead>
                                  <tbody>
                                     <?php
                                        $i = 0;
                                        foreach($member as $adm)
                                        {
                                          $i++;
                                          $img = explode('_-_', $adm['images']);
                                          ?>
                                          <tr>
                                            <td><?php echo $i; ?></td>
                                            <td><img src="../../../../Dreamhome/upload/Banner/<?php echo $img[0]; ?>" style="height: 50px; width: 50px; border-radius: 100px; "/></td>
                                            <td><?php echo $adm['title'];; ?></td>
                                            <td>
                                              <a href="<?php echo site_url('Dashboard/Banner_view/'.$adm['id']);?>" style="color: white;" class="btn btn-info btn-sm"><i class="fas fa-eye"></i></a> 
                                              <button type="button" class="btn btn-danger btn-sm dlt_click" id="<?php echo $adm['id']; ?>" data-name="<?php echo $adm['title']; ?>" data-url="<?php echo site_url('Dashboard/del_Banner/'.$adm['id']);?>"><i class="fas fa-trash-alt"></i></button>
                                            </td>
                                          </tr>
                                          <?php
                                        }
                                        ?>
                                  </tbody>
                                </table>
                          </div> 
                      </div>
                    </div>
                  </div>
                </div>
            </div>
          </div>

         

       

        </div>
        <!-- /.container-fluid -->

      </div>
    <div class="modal fade model-sm" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Are you Sure to delete this?</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
           
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-danger">
             <a href="" style="color: white;" class="delete_id">Delete</a> 
            </button>
          </div>
        </div>
      </div>
      </div>