<!-- Begin Page Content -->
<?php echo form_open_multipart('Dashboard/Add_Banner',array("class"=>"form-horizontal")); ?>


        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Add Banner</h1>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo base_url('Dashboard');?>">Home</a></li>
                <li class="breadcrumb-item active">Banner Detail</li>
              </ol>
            </nav>
          </div>
          <div class="container-fluid">
            <div class="card o-hidden border-0 shadow-lg my-3">
                <div class="card-body p-0">
                  <div class="card shadow mb-4">
                    <div class="card-header py-3">
                      <center><span class="error_form_msg"></span></center>
                       </i><a class="float-right" href="<?php echo base_url('Dashboard/Portfolio');?>"><i class=" text-danger"><b>X<b></i></a> <br><br>
                        <b class="float-left  text-danger"><h4>Add Banner</h4></b><br><hr>

                      <div class="row col-lg-12">
                        <div class="col-lg-6 float-left">
                           <label class="col-form-label float-left"><span class="text-danger">*</span>Images(3 pic only)</label>
                           <input  type="file" name="images[]" class="form-control" id="images" multiple="multiple">
                        </div>
                        
                      </div>
                      <div class="row col-lg-12 mt-3">
                        <div class="col-lg-12 float-left">
                          <label class="col-form-label float-left"><span class="text-danger">*</span>Title</label>
                          <input  type="text" name="title" class="form-control " id="title" placeholder="Title">
                        </div>
                      </div>
                       
                      
                       <div class="row mt-4">
                        <div class="col-md-6 mt-4">
                            <input type="submit" name="upload" class="btn btn-success" value="Save">
                             <a class="btn btn-danger" href="<?php echo base_url('Dashboard/Portfolio');?>">Cancel</a>
                        </div>
                      </div>


                    </div>
                  </div>
                </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>

<?php echo form_close(); ?>
