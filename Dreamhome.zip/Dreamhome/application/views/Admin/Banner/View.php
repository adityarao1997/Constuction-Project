<?php 
    $this->load->view('Admin/Layout/header');
    $this->load->view('Admin/Banner/ViewMain.php');
    $this->load->view('Admin/Layout/footer');
?>