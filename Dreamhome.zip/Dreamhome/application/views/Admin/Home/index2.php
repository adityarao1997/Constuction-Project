<?php 

   	
    $this->load->view('Admin/Layout/header');
    $this->load->view('Admin/Home/index_main2.php');
    $this->load->view('Admin/Layout/footer');


?>






