<!DOCTYPE html>
<html lang="en">
<head>
<title>Dream Homes Ranchi - A step beyond building your Dream Home.</title>
<meta charset="UTF-8">
<meta name="description" content="Dream Homes Ranchi - A step beyond building your Dream Home.">
<meta name="keywords" content="">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- Favicon -->
<link href="<?php echo base_url()?>assets/img/favicon.png" rel="shortcut icon"/>
<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
<!-- Stylesheets -->
<link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css%2bfont-awesome.min.css%2banimate.css%2bowl.carousel.css%2bstyle.css.pagespeed.cc.oz0PoXnudW.css"/>
<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
		<style>
/* width */
::-webkit-scrollbar {
  width: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px gray; 
  border-radius: 10px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #C49500; 
  border-radius: 10px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #C49539; 
}
</style>
</head>
<body>
<!-- Page Preloder -->
<div id="preloder">
<div class="loader"></div>
</div>
<!-- Header section start -->
<header class="header-area">
<a href="index.html" class="logo-area">
<img src="<?php echo base_url()?>assets/img/logo.png" alt="">
</a>
<div class="nav-switch">
<i class="fa fa-bars"></i>
</div>
<div class="phone-number">+91-62870 10008</div>
<nav class="nav-menu">
<ul>
<li><a href="<?php echo base_url('HomeDash')?>">Home</a></li>
<li><a href="<?php echo base_url('HomeDash/about_us')?>">About us</a></li>
<li class="active"><a href="<?php echo base_url('HomeDash/portfolio')?>">Our Projects</a></li>
<li><a href="<?php echo base_url('HomeDash/contact_us')?>">Contact Us</a></li>
</ul>
</nav>
</header>
<!-- Header section end -->
<!-- Page header section start -->
<section class="page-header-section set-bg" data-setbg="<?php echo base_url()?>assets/img/header-bg.jpg">
<div class="container">
<h1 class="header-title">Portfolio<span>.</span></h1>
</div>
</section>
<!-- Page header section end -->
<!-- Page section start -->
<div class="projects-section pb50" style="padding-top: 50px;">
<div class="container">
<div class="row">
<div class="col-lg-9">
<ul class="projects-filter-nav">
</ul>
</div>
</div>
</div>
<div id="projects-carousel" class="projects-slider">
<?php
   $data = $this->Admin_model->get_all_portfolioList();
   foreach($data as $key)
   {
     $img = explode('_-_',$key['images']);
  ?>
  
    <div class="single-project set-bg rest" data-setbg="../../../../Dreamhome/upload/Project/<?php echo $img[0]; ?>">
      <div class="project-content">
        <h2><?php echo $key['title'];?></h2>
        <p><?php echo $key['city'];?></p>
        <a href="<?php echo base_url('HomeDash/Details/'.$key['id'])?>" class="seemore">Know More </a>
      </div>
    </div>
   <?php }?>
</div>
</div>

<section class="promo-section pt-0">
<div class="promo-box set-bg" data-setbg="<?php echo base_url()?>assets/img/bg.jpg">
<div class="container">
<div class="row">
<div class="col-lg-9 promo-text">
<h1>In need of <span>Loan</span> Assistance?</h1>
<p>Get your dream home at an effordable interest rate.</p>
</div>
<div class="col-lg-3 text-lg-right">
<a href="<?php echo base_url('HomeDash/contact_us')?>" class="site-btn sb-light mt-4">Enquire Now</a>
</div>
</div>
</div>
</div>
</section>

<!-- Clients section end -->
<!-- Footer section start -->
<footer class="footer-section">
<div class="footer-social">
<div class="social-links">
<a href="#"><i class="fa fa-facebook"></i></a>
<a href="#"><i class="fa fa-instagram"></i></a>
<a href="#"><i class="fa fa-youtube"></i></a>
</div>
</div>
<div class="container">
<div class="row">
<div class="col-lg-9 offset-lg-3">
<div class="row">
<div class="col-md-4">
<div class="footer-item">
<ul>
<li><a href="<?php echo base_url('HomeDash/portfolio')?>">Our Projects</a></li>
</ul>
</div>
</div>
<div class="col-md-4">
<div class="footer-item">
<ul>
<li><a href="<?php echo base_url('HomeDash')?>">Home</a></li>
<li><a href="<?php echo base_url('HomeDash/about_us')?>">About us</a></li>
</ul>
</div>
</div>
<div class="col-md-4">
<div class="footer-item">
<ul>
<li><a href="<?php echo base_url('HomeDash/contact_us')?>">Home Loan Assistance</a></li>
<li><a href="<?php echo base_url('HomeDash/contact_us')?>">Contact us</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="copyright">Copyright &copy; <script>document.write(new Date().getFullYear());</script> All rights reserved. <br>Hand-crafted & Maintained by <a href="https://powehi.in" target="_blank">Powehi</a> & <a href="http://techhelper.in/" target="_blank">TechHelper</a></div>
</footer>
<!-- Footer section end -->
<!--====== Javascripts & Jquery ======-->
<script src="<?php echo base_url()?>assets/js/jquery-2.1.4.min.js.pagespeed.jm.BnirE05kB4.js"></script>
<script src="<?php echo base_url()?>assets/js/bootstrap.min.js%2bisotope.pkgd.min.js.pagespeed.jc.yy1tGGqk3I.js"></script><script>eval(mod_pagespeed_iBTRy9BIKF);</script>
<script>eval(mod_pagespeed_vxb9y4bpWL);</script>
<script src="<?php echo base_url()?>assets/js/owl.carousel.min.js.pagespeed.jm.XFaRvc2D_z.js"></script>
<script>//<![CDATA[
"use strict";$.fn.owlRemoveItem=function(num){var owl_data=$(this).data('owlCarousel');owl_data._items=$.map(owl_data._items,function(data,index){if(index!=num)return data;})
$(this).find('.owl-item').eq(num).remove();}
$.fn.owlFilter=function(data,callback){var owl=this,owl_data=$(owl).data('owlCarousel'),$elemCopy=$('<div>').css('display','none');if(typeof($(owl).data('owl-clone'))=='undefined'){$(owl).find('.owl-item:not(.cloned)').clone().appendTo($elemCopy);$(owl).data('owl-clone',$elemCopy);}else{$elemCopy=$(owl).data('owl-clone');}owl.trigger('replace.owl.carousel',['<div/>']);switch(data){case'*':$elemCopy.children().each(function(){owl.trigger('add.owl.carousel',[$(this).clone()]);})
break;default:$elemCopy.find(data).each(function(){owl.trigger('add.owl.carousel',[$(this).parent().clone()]);})
break;}owl.owlRemoveItem(0);owl.trigger('refresh.owl.carousel').trigger('to.owl.carousel',[0]);if(callback)callback.call(this,owl);}
//]]></script>
<script src="<?php echo base_url()?>assets/js/magnific-popup.min.js%2bcircle-progress.min.js.pagespeed.jc.doBJGKBjl_.js"></script><script>eval(mod_pagespeed_dNC3ye8kAP);</script>
<script>eval(mod_pagespeed_B3zsGp7_m_);</script>
<script src="<?php echo base_url()?>assets/js/main.js.pagespeed.jm.c7tI4oj_mR.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','UA-23581568-13');</script>
</body>


</html>