
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title><?php echo $port['title']?>, <?php echo $port['city']?></title>

    <!-- Favicon  -->
    <link rel="icon" href="<?php echo base_url()?>assets/img/favicon.png">

    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo base_url()?>assets/properties/style.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
<!-- Stylesheets -->
<link rel="stylesheet" href="<?php echo base_url()?>assets/css/bootstrap.min.css%2bfont-awesome.min.css%2banimate.css%2bowl.carousel.css%2bstyle.css.pagespeed.cc.oz0PoXnudW.css"/>
    <style>
/* width */
::-webkit-scrollbar {
  width: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px gray; 
  border-radius: 10px;
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: #C49500; 
  border-radius: 10px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #C49539; 
}
</style>
</head>

<body>
<!-- Page Preloder -->
<div id="preloder">
<div class="loader"></div>
</div>
<!-- Header section start -->
<header class="header-area">
<a href="index.html" class="logo-area">
<img src="<?php echo base_url()?>assets/img/logo.png" alt="">
</a>
<div class="nav-switch">
<i class="fa fa-bars"></i>
</div>
<div class="phone-number">+91-62870 10008</div>
<nav class="nav-menu">
<ul>
<li><a href="<?php echo base_url('HomeDash')?>">Home</a></li>
<li><a href="<?php echo base_url('HomeDash/about_us')?>">About us</a></li>
<li class="active"><a href="<?php echo base_url('HomeDash/portfolio')?>">Our Projects</a></li>
<li><a href="<?php echo base_url('HomeDash/contact_us')?>">Contact Us</a></li>
</ul>
</nav>
</header>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Breadcumb Area Start ##### -->
<section class="page-header-section set-bg" data-setbg="<?php echo base_url()?>assets/properties/img/gardenvalley/gardenvalley1.jpg">
<div class="container">
<h1 class="header-title"><?php echo $port['title']?><span>.</span></h1>
</div>
</section>
    <!-- ##### Breadcumb Area End ##### -->


    <!-- ##### Listings Content Area Start ##### -->
    <section class="listings-content-wrapper section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                   
                    <!-- Single Listings Slides -->
                    <div class="single-listings-sliders owl-carousel">
                        <!-- Single Slide -->
                        <?php
                          $img = explode('_-_',$port['images']);
                          $i=0;
                         foreach ($img as $imageKey) {
                        ?>
                        <img src="../../../../Dreamhome/upload/Project/<?php echo $imageKey; ?>" alt="">
                        <?php
                        $i++;
                        }
                        ?>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-12 col-lg-8">
                    <div class="listings-content">
                        <!-- Price -->
                        <!-- <div class="list-price">
                            <p>$945 679</p>
                        </div> -->
                        <h5><?php echo $port['title']?></h5>
                        <p class="location"><img src="<?php echo base_url()?>assets/properties/img/icons/location.png" alt=""><?php echo $port['description']?></p>
                        <!-- Meta -->
                        <!-- <div class="property-meta-data d-flex align-items-end">
                            <div class="new-tag">
                                <img src="img/icons/new.png" alt="">
                            </div>
                            <div class="bathroom">
                                <img src="img/icons/bathtub.png" alt="">
                                <span>2</span>
                            </div>
                            <div class="garage">
                                <img src="img/icons/garage.png" alt="">
                                <span>2</span>
                            </div>
                            <div class="space">
                                <img src="img/icons/space.png" alt="">
                                <span>120 sq ft</span>
                            </div>
                        </div> -->
                        <!-- Core Features -->
                        <ul class="listings-core-features d-flex align-items-center">
                            <?php
                              $available = explode('--',$port['availabe']);
                              $i=0;
                              foreach ($available as $key)
                            {?>
                            <li><i class="fa fa-check" aria-hidden="true"></i><?=$key?></li>
                            <?php }?>
                        </ul>
                        <!-- Listings Btn Groups -->
                        <!-- <div class="listings-btn-groups">
                            <a href="#" class="btn south-btn">See Floor plans</a>
                            <a href="#" class="btn south-btn active">calculate mortgage</a>
                        </div> -->
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="contact-realtor-wrapper">
                        <div class="realtor-info">
                            <div class="realtor---info">
                                <h2>Free Home Loan Assistance</h2>
                                <p>Contact Us</p>
                                <h6><img src="<?php echo base_url()?>assets/properties/img/icons/phone-call.png" alt=""> +91-62870 10008</h6>
                                <h6><img src="<?php echo base_url()?>assets/properties/img/icons/envelope.png" alt=""> amridhikamdeo10008@gmail.com</h6>
                            </div>
                            <div class="realtor--contact-form">
                                <form action="#" method="post">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="realtor-name" placeholder="Your Name">
                                    </div>
                                    <div class="form-group">
                                        <input type="number" class="form-control" id="realtor-number" placeholder="Your Number">
                                    </div>
                                    <div class="form-group">
                                        <input type="enumber" class="form-control" id="realtor-email" placeholder="Your Mail">
                                    </div>
                                    <div class="form-group">
                                        <textarea name="message" class="form-control" id="realtor-message" cols="30" rows="10" placeholder="Your Enquiry"></textarea>
                                    </div>
                                    <button type="submit" class="btn south-btn">Send Message</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- ##### Icon Boxes ##### -->
                <div class="col-12">
                    <div style="padding-bottom: 50px;">
                        <h5>Builder Contacts</h5>
                    </div>
                </div>

                <!-- Single Service Area -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-service-area mb-100">
                        <div class="service-content">
                            <h5>Contact No</h5>
                            <p><?php echo $port['builder_cont']?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Single Service Area -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-service-area mb-100">
                        <div class="service-content">
                            <h5>Email ID</h5>
                            <p><?php echo $port['builder_email']?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Single Service Area -->
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="single-service-area mb-100">
                        <div class="service-content">
                            <h5>Website</h5>
                            <p>www.vinayakassociate.in</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Listing Maps -->
            <div class="row">
                <div class="col-12">
                    <div class="listings-maps mt-10">
                    <?php echo $port['iframe']?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Listings Content Area End ##### -->

    <!-- ##### Footer Area Start ##### -->
<footer class="footer-section">
<div class="footer-social">
<div class="social-links">
<a href="#"><i class="fa fa-facebook"></i></a>
<a href="#"><i class="fa fa-instagram"></i></a>
<a href="#"><i class="fa fa-youtube"></i></a>
</div>
</div>
<div class="container">
<div class="row">
<div class="col-lg-9 offset-lg-3">
<div class="row">
<div class="col-md-4">
<div class="footer-item">
<ul>
<li><a href="<?php echo base_url('HomeDash/portfolio')?>">Our Projects</a></li>
</ul>
</div>
</div>
<div class="col-md-4">
<div class="footer-item">
<ul>
<li><a href="<?php echo base_url('HomeDash')?>">Home</a></li>
<li><a href="<?php echo base_url('HomeDash/about_us')?>">About us</a></li>
</ul>
</div>
</div>
<div class="col-md-4">
<div class="footer-item">
<ul>
<li><a href="<?php echo base_url('HomeDash/contact_us')?>">Home Loan Assistance</a></li>
<li><a href="<?php echo base_url('HomeDash/contact_us')?>">Contact us</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="copyright">Copyright &copy; <script>document.write(new Date().getFullYear());</script> All rights reserved. <br>Hand-crafted & Maintained by <a href="https://powehi.in" target="_blank">Powehi</a> & <a href="http://techhelper.in/" target="_blank">TechHelper</a></div>
</footer>
    <!-- ##### Footer Area End ##### -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="<?php echo base_url()?>assets/properties/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="<?php echo base_url()?>assets/properties/js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="<?php echo base_url()?>assets/properties/js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="<?php echo base_url()?>assets/properties/js/plugins.js"></script>
    <script src="<?php echo base_url()?>assets/properties/js/classy-nav.min.js"></script>
    <script src="<?php echo base_url()?>assets/properties/js/jquery-ui.min.js"></script>
    <!-- Active js -->
    <script src="<?php echo base_url()?>assets/properties/js/active.js"></script>
    <!-- Google Maps -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAwuyLRa1uKNtbgx6xAJVmWy-zADgegA2s"></script>
    <script src="<?php echo base_url()?>assets/properties/js/map-active.js"></script>

    <script src="<?php echo base_url()?>assets/js/jquery-2.1.4.min.js.pagespeed.jm.BnirE05kB4.js"></script>
<script src="<?php echo base_url()?>assets/properties/js/bootstrap.min.js%2bisotope.pkgd.min.js.pagespeed.jc.yy1tGGqk3I.js"></script><script>eval(mod_pagespeed_iBTRy9BIKF);</script>
<script>eval(mod_pagespeed_vxb9y4bpWL);</script>
<script src="<?php echo base_url()?>assets/js/owl.carousel.min.js.pagespeed.jm.XFaRvc2D_z.js"></script>
<script>//<![CDATA[
"use strict";$.fn.owlRemoveItem=function(num){var owl_data=$(this).data('owlCarousel');owl_data._items=$.map(owl_data._items,function(data,index){if(index!=num)return data;})
$(this).find('.owl-item').eq(num).remove();}
$.fn.owlFilter=function(data,callback){var owl=this,owl_data=$(owl).data('owlCarousel'),$elemCopy=$('<div>').css('display','none');if(typeof($(owl).data('owl-clone'))=='undefined'){$(owl).find('.owl-item:not(.cloned)').clone().appendTo($elemCopy);$(owl).data('owl-clone',$elemCopy);}else{$elemCopy=$(owl).data('owl-clone');}owl.trigger('replace.owl.carousel',['<div/>']);switch(data){case'*':$elemCopy.children().each(function(){owl.trigger('add.owl.carousel',[$(this).clone()]);})
break;default:$elemCopy.find(data).each(function(){owl.trigger('add.owl.carousel',[$(this).parent().clone()]);})
break;}owl.owlRemoveItem(0);owl.trigger('refresh.owl.carousel').trigger('to.owl.carousel',[0]);if(callback)callback.call(this,owl);}
//]]></script>
<script src="<?php echo base_url()?>assets/js/magnific-popup.min.js%2bcircle-progress.min.js.pagespeed.jc.doBJGKBjl_.js"></script><script>eval(mod_pagespeed_dNC3ye8kAP);</script>
<script>eval(mod_pagespeed_B3zsGp7_m_);</script>
<script src="<?php echo base_url()?>assets/js/main.js.pagespeed.jm.c7tI4oj_mR.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','UA-23581568-13');</script>

</body>

</html>