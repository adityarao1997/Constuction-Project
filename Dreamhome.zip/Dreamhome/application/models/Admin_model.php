<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
* 
*/
class Admin_model extends CI_Model
{
  	
  	function __construct()
  	{
  	     parent::__construct();
  	}

 	/*
     *   Profile Detail Incubatee
     */
    function get_current_profile()
    {
          $Login_id = $this->session->userdata('id');
          $query=$this->db->query("select * from admin where id='$Login_id'");
          return $query->result_array();
         
    }

    /*
     *   Contact Us Detail  
     */ 

    function get_all_request_count()
    {
        $this->db->from('contact_us');
        return $this->db->count_all_results();
    }
    function get_all_requestList($params = array())
    {
        $this->db->order_by('id', 'desc');
        return $this->db->get('contact_us')->result_array();
    }
    function get_request($id)
    {
        return $this->db->get_where('contact_us',array('id'=>$id))->row_array();
    }
    function update_request($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('contact_us',$params);
    }
    function delete_request($id)
    {
        return $this->db->delete('contact_us',array('id'=>$id));
    }
    function add_contact_details($name,$email,$mobile,$description)
    { 
        $data = array(

            'name' => $name,
            'email' => $email,
            'mobile' => $mobile,
            'description' => $description,
            
                );
        return $this->db->insert('contact_us', $data); 
    }

    function get_all_portfolio_count()
    {
        $this->db->from('project');
        return $this->db->count_all_results();
    }
    function get_all_portfolioList($params = array())
    {
        $this->db->order_by('id', 'desc');
        return $this->db->get('project')->result_array();
    }
    function get_portfolio($id)
    {
        return $this->db->get_where('project',array('id'=>$id))->row_array();
    }
    
    function delete_portfolio($id)
    {
        return $this->db->delete('project',array('id'=>$id));
    }
    function add_portfolio_details($data=array())
    { 
        return $this->db->insert('project', $data);
    }



    function get_all_Banner_count()
    {
        $this->db->from('banner_pic');
        return $this->db->count_all_results();
    }
    function get_all_BannerList($params = array())
    {
        $this->db->order_by('id', 'desc');
        return $this->db->get('banner_pic')->result_array();
    }
    function get_Banner($id)
    {
        return $this->db->get_where('banner_pic',array('id'=>$id))->row_array();
    }
    
    function delete_Banner($id)
    {
        return $this->db->delete('banner_pic',array('id'=>$id));
    }
    function add_Banner_details($data=array())
    { 
        return $this->db->insert('banner_pic', $data);
    }

     

}
?>
