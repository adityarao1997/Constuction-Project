<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
* 
*/
class Login_mdl extends CI_Model
{
  	
  	function __construct()
  	{
  	     parent::__construct();
  	}

 	/*
     * Other Login Code
     */
    public function login_all($email, $password)
    {
       $query = $this->db->where(['email'=>$email, 'password'=>$password])->get('admin');
          	if($query->num_rows() > 0)
          	{
         		return $query->row()->id;
          	}
    } 

}
?>
