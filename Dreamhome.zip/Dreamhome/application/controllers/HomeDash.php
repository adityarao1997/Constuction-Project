<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class HomeDash extends CI_Controller
{

	/*
	 * Index Page for this controller.
	 */
	
	function __construct()
    {
        parent::__construct();
        $this->load->model('Admin_model');        
    }

    /*
    *   Index
    */
    function index()
    { 
        $this->load->view('web/home/index');
    }
    function about_us()
    {  
        $this->load->view('web/About/Aboutus');
    }

    function contact_us()
    {  
        $this->load->view('web/contact/contactus');
    }

    function contact_ad()
    {
        if( $this->input->post('upload') )    // if form is posted
        {
           
          $this->form_validation->set_rules('name','name','required');
          $this->form_validation->set_rules('email','email','required');
          $this->form_validation->set_rules('mobile','mobile','required');
          $this->form_validation->set_rules('description','description','required');
            
          $name = $this->input->post('name');
          $email = $this->input->post('email');
          $mobile = $this->input->post('mobile');
          $description = $this->input->post('description');

            if($this->Admin_model->add_contact_details($name,$email,$mobile,$description))
            {  
                return redirect('HomeDash');
            }else
            {
                redirect('HomeDash/contact_us');
            }
             
        } 
        redirect('HomeDash/contact_us');
    }

    function portfolio()
    {  
        $this->load->view('web/porfolio/project_port');
    }
    function Details($id)
    {  
        
        $data['port'] = $this->Admin_model->get_portfolio($id);
        $data['_view'] =  'web/porfolio/project_detail';
        $this->load->view('web/porfolio/project_detail',$data);
    }
}
?>