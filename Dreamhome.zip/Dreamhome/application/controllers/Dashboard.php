<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller
{

	/*
	 * Index Page for this controller.
	 */
	
	function __construct()
    {
        parent::__construct();
        $this->load->model('Login_mdl');
        $this->load->model('Admin_model');
                
    }
   /*
    *   Index
    */
    function index()
    {
        $data['cur_page'] = "Dashboard";
         if(!$this->session->userdata('id')){
                  return redirect('Admin_re');
            }else{
                $this->load->view('Admin/Home/index',$data);
              }
    }

    /* Contact Us details*/
    function Contact_dt()
    {    
         $params['limit'] = 'RECORDS_PER_PAGE'; 
         $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
         
         $config = $this->config->item('pagination');
         $config['base_url'] = site_url('Member/enquery/Viewrequest');
         $config['total_rows'] = $this->Admin_model->get_all_request_count();
         $this->pagination->initialize($config);
 
         $data['member'] = $this->Admin_model->get_all_requestList($params);
       
         $data['cur_page'] = "dashboard";
         $data['_view'] =  'Admin/contact/Viewrequest';
         $this->load->view('Admin/contact/Viewrequest',$data);
    }
    function Contact_dt_view($id)
    {
        $data['cur_page'] = "dashboard";
        $data['cont'] = $this->Admin_model->get_request($id);
        $data['_view'] =  'Admin/contact/View';
        $this->load->view('Admin/contact/View',$data);
    }
    function del_contact($id)
    {
      $contact = $this->Admin_model->get_request($id);

      if(isset($contact['id']))
      {
          $this->Admin_model->delete_request($id);
          redirect('Dashboard/Contact_dt');
      }
      else
          show_error('The admin you are trying to delete does not exist.');
    }


     /* Project Us details*/
     function Portfolio()
     {    
          $params['limit'] = 'RECORDS_PER_PAGE'; 
          $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
          
          $config = $this->config->item('pagination');
          $config['base_url'] = site_url('Member/enquery/Viewrequest');
          $config['total_rows'] = $this->Admin_model->get_all_portfolio_count();
          $this->pagination->initialize($config);
  
          $data['member'] = $this->Admin_model->get_all_portfolioList($params);
        
          $data['cur_page'] = "dashboard";
          $data['_view'] =  'Admin/Project/Viewport';
          $this->load->view('Admin/Project/Viewport',$data);
     }

      /* Project Us details*/
    function Add_Portfolio()
    {    
        if( $this->input->post('upload') )    // if form is posted
        {
           
          $this->form_validation->set_rules('title','title','required');
          $this->form_validation->set_rules('address','address','required');
          $this->form_validation->set_rules('city','city','required');
          $this->form_validation->set_rules('description','description','required');
          $this->form_validation->set_rules('builder_cont','builder_cont','required');
          $this->form_validation->set_rules('builder_email','builder_email','required');
          $this->form_validation->set_rules('iframe','iframe','required');
            
          $title = $this->input->post('title');
          $address = $this->input->post('address');
          $city = $this->input->post('city');
          $description = $this->input->post('description');
          $builder_cont = $this->input->post('builder_cont');
          $builder_email = $this->input->post('builder_email');
          $iframe = $this->input->post('iframe');

          $availabe ='';
          foreach ($this->input->post('availabe') as $key => $value) 
          {
            if($availabe == "")
            {
                $availabe =  $value["availabe"];
            }
            else
            {
                $availabe .= '--'.$value["availabe"];
            }
          
          }

          $images = "";
          $this->load->library('upload');
          $image = array();
          $ImageCount = count($_FILES['images']['name']);
         
            for($i = 0; $i < $ImageCount; $i++)
            {
                $pic_ext = explode('.', $_FILES['images']['name'][$i]);
                $pic_ext = end($pic_ext);
                $pic_name = 'portfolio_images'.$i.'-'.uniqid().date('Y-m-d').$pic_ext;
                $_FILES['file']['name']       = $_FILES['images']['name'][$i];
                $_FILES['file']['type']       = $_FILES['images']['type'][$i];
                $_FILES['file']['tmp_name']   = $_FILES['images']['tmp_name'][$i];
                $_FILES['file']['error']      = $_FILES['images']['error'][$i];
                $_FILES['file']['size']       = $_FILES['images']['size'][$i];

                // File upload configuration
                $uploadPath = './upload/Project/';

                $config['upload_path'] = $uploadPath;
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name']= $pic_name;
                
                // Load and initialize upload library
                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                // Upload file to server
                if($this->upload->do_upload('file'))
                {
                    // Uploaded file data
                    $imageData = $this->upload->data();
                    $uploadImgData[$i]['images'] = $imageData['file_name'];
                    $add = "";
                    if($images != "")
                    {
                    $add = '_-_';
                    }
                    $images .= $add.$uploadImgData[$i]['images'];
                }
            }
            if(!empty($images))
            {
                $params = array(
                'images'=>$images, 
                'title' => $title,
                'address' => $address,
                'city' => $city,
                'description' => $description,
                'builder_cont' => $builder_cont,
                'builder_email' => $builder_email,
                'builder_email' => $builder_email,
                'iframe' => $iframe,
                );
                            
                $this->Admin_model->add_portfolio_details($params);    
                return redirect('Dashboard/Portfolio');          
            }
            else
            {
                print_r($pic_name);
            }    
             
        } 
        $data['cur_page'] = "dashboard";
        $data['_view'] =  'Admin/Project/AddPort';
        $this->load->view('Admin/Project/AddPort',$data);
    }

    function portfolio_view($id)
    {
        $data['cur_page'] = "dashboard";
        $data['cont'] = $this->Admin_model->get_portfolio($id);
        $data['_view'] =  'Admin/Project/View';
        $this->load->view('Admin/Project/View',$data);
    }

    function del_portfolio($id)
    {
      $port = $this->Admin_model->get_portfolio($id);

      if(isset($port['id']))
      {
          $this->Admin_model->delete_portfolio($id);
          redirect('Dashboard/Portfolio');
      }
      else
          show_error('The admin you are trying to delete does not exist.');
    }


    /* Project Us details*/
    function Banner()
    {    
         $params['limit'] = 'RECORDS_PER_PAGE'; 
         $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
         
         $config = $this->config->item('pagination');
         $config['base_url'] = site_url('Member/enquery/Viewrequest');
         $config['total_rows'] = $this->Admin_model->get_all_Banner_count();
         $this->pagination->initialize($config);
 
         $data['member'] = $this->Admin_model->get_all_BannerList($params);
       
         $data['cur_page'] = "dashboard";
         $data['_view'] =  'Admin/Banner/ViewBanner';
         $this->load->view('Admin/Banner/ViewBanner',$data);
    }

     /* Project Us details*/
    function Add_Banner()
    {    
       if( $this->input->post('upload') )    // if form is posted
       {
          
         $this->form_validation->set_rules('title','title','required');
        
         $title = $this->input->post('title');
        
         $images = "";
         $this->load->library('upload');
         $image = array();
         $ImageCount = count($_FILES['images']['name']);
        
           for($i = 0; $i < $ImageCount; $i++)
           {
               $pic_ext = explode('.', $_FILES['images']['name'][$i]);
               $pic_ext = end($pic_ext);
               $pic_name = 'portfolio_images'.$i.'-'.uniqid().date('Y-m-d').$pic_ext;
               $_FILES['file']['name']       = $_FILES['images']['name'][$i];
               $_FILES['file']['type']       = $_FILES['images']['type'][$i];
               $_FILES['file']['tmp_name']   = $_FILES['images']['tmp_name'][$i];
               $_FILES['file']['error']      = $_FILES['images']['error'][$i];
               $_FILES['file']['size']       = $_FILES['images']['size'][$i];

               // File upload configuration
               $uploadPath = './upload/Banner/';

               $config['upload_path'] = $uploadPath;
               $config['allowed_types'] = 'jpg|jpeg|png|gif';
               $config['file_name']= $pic_name;
               
               // Load and initialize upload library
               $this->load->library('upload', $config);
               $this->upload->initialize($config);

               // Upload file to server
               if($this->upload->do_upload('file'))
               {
                   // Uploaded file data
                   $imageData = $this->upload->data();
                   $uploadImgData[$i]['images'] = $imageData['file_name'];
                   $add = "";
                   if($images != "")
                   {
                   $add = '_-_';
                   }
                   $images .= $add.$uploadImgData[$i]['images'];
               }
           }
           if(!empty($images))
           {
               $params = array(
               'images'=>$images, 
               'title' => $title,
               );
                           
               $this->Admin_model->add_Banner_details($params);    
               return redirect('Dashboard/Banner');          
           }
           else
           {
               print_r($pic_name);
           }    
            
       } 
       $data['cur_page'] = "dashboard";
       $data['_view'] =  'Admin/Banner/AddBanner';
       $this->load->view('Admin/Banner/AddBanner',$data);
    }

    function Banner_view($id)
    {
        $data['cur_page'] = "dashboard";
        $data['ban_post'] = $this->Admin_model->get_Banner($id);
        $data['_view'] =  'Admin/Banner/View';
        $this->load->view('Admin/Banner/View',$data);
    }

    function del_Banner($id)
    {
      $port = $this->Admin_model->get_Banner($id);

      if(isset($port['id']))
      {
          $this->Admin_model->delete_Banner($id);
          redirect('Dashboard/Banner');
      }
      else
          show_error('The admin you are trying to delete does not exist.');
    }
}
?>