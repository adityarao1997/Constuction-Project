<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_re extends CI_Controller
{

	/*
	 * Index Page for this controller.
	 */
	
	function __construct()
    {
        parent::__construct();
        $this->load->model('Login_mdl');
                
    }

    /*
    *   Index Member Login
    */
    function index()
    {
        $this->session->unset_userdata('id');
        $data['_view'] =  'Layout/Login'; 
        $this->load->view('Layout/Login',$data);
    }
   /*
    *   Admin Login
    */
    public function logs_dt()
    {
        $this->form_validation->set_rules('email', 'email', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
        $this->form_validation->set_error_delimiters('<div class="error">','</div>');
        if ($this->form_validation->run()) 
        {
                    
            $email = $this->input->post('email');
            $password = $this->input->post('password');
                $id = $this->Login_mdl->login_all($email, $password);
                if($id > 0)
                {
                    $this->session->set_userdata(['id'=>$id]);
                    return redirect('Dashboard');
                }
              else
                {
                    $error = $this->session->set_flashdata('login_response', 'Invalid username/password');
                    return redirect('Admin_re/logs_dt');
                }
            }
          else
            {
                $data['_view'] =  'Layout/Login';
                $this->load->view('Layout/Login',$data);
            }

    }
  
}
?>