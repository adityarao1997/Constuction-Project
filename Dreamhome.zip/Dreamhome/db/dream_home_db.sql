-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2020 at 11:04 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dream@home_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(15) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `crate_dt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `crate_dt`, `status`) VALUES
(1, 'Aditya Pramod Rao', 'adityarao@gmail.com', 'ad123', '2020-11-25 19:47:26', 1);

-- --------------------------------------------------------

--
-- Table structure for table `banner_pic`
--

CREATE TABLE `banner_pic` (
  `id` int(50) NOT NULL,
  `title` varchar(500) NOT NULL,
  `images` varchar(1000) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `banner_pic`
--

INSERT INTO `banner_pic` (`id`, `title`, `images`, `status`) VALUES
(2, 'Dream Home New ', 'portfolio_images0-5fbf7887f244b2020-11-26jpg.jpg_-_portfolio_images1-5fbf7888019dd2020-11-26jpg.jpg_-_portfolio_images2-5fbf788804c082020-11-26jpg.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `crate_dt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `respone` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `mobile`, `description`, `crate_dt`, `respone`) VALUES
(1, 'Divya Singh', 'divyasingh@gmail.com', '7985540250', 'Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen boo', '2020-11-25 20:17:01', 0),
(2, 'Aditya Pramod Rao', 'adityarao.csdeveloper@gmail.com', '9179803807', 'Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen boo', '2020-11-25 20:17:01', 0),
(4, 'Pappi Solanki', 'Dharmendra.solanky04@gmail.com', '7471158167', 'check', '2020-11-25 20:49:17', 0),
(5, 'check', 'check', 'Ranchi', 'dsad', '2020-11-25 22:40:00', 0),
(6, 'check', 'check', 'check', 'chek', '2020-11-26 10:03:42', 0);

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `id` int(50) NOT NULL,
  `title` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `city` varchar(100) NOT NULL,
  `images` varchar(1000) NOT NULL,
  `description` text NOT NULL,
  `builder_cont` varchar(20) NOT NULL,
  `builder_email` varchar(100) NOT NULL,
  `create_dt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`id`, `title`, `address`, `city`, `images`, `description`, `builder_cont`, `builder_email`, `create_dt`, `status`) VALUES
(3, 'Dream Heaven New Phase', 'Beside Don Bosco School Devi Nagar Hesag Hatia, Ranchi, Jharkhand 834003, India', 'Ranchi', 'portfolio_images0-5fbf44cfe101d2020-11-26jpg.jpg_-_portfolio_images1-5fbf44cfecd4e2020-11-26jpg.jpg_-_portfolio_images2-5fbf44cfef88c2020-11-26jpg.jpg', 'Vinayak Garden Valley in Hesag, Ranchi by Vinayak Developers and Associates is a residential project. It is an under construction project with possession offered in Jan, 2021. The project is spread over a total area of 5 acres of land. It has 70% of open space. Vinayak Garden Valley has a total of 6 towers. The construction is of 13 floors.', '7471158167', 'aditya@gmail.com', '2020-11-26 06:01:51', 0),
(4, 'check we are working', 'xyz address', 'Bhopal', 'portfolio_images0-5fbf4dac443ca2020-11-26jpg.jpg_-_portfolio_images1-5fbf4dac4a9362020-11-26jpg.jpg_-_portfolio_images2-5fbf4dac4dbc02020-11-26jpg.jpg', 'Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs. The passage is attributed to an unknown typesetter in the 15th century who is thought to have scrambled parts of Cicero\'s De Finibus Bonorum et Malorum for use in a type specimen book.', '787878787878', 'sdaksda@hsmda.com', '2020-11-26 06:39:40', 0),
(5, '', '', '1', 'portfolio_images0-5fbf4e72cc95d2020-11-26jpg.jpg_-_portfolio_images1-5fbf4e72cf00d2020-11-26jpg.jpg_-_portfolio_images2-5fbf4e72d1a342020-11-26jpg.jpg', '', '', '', '2020-11-26 06:42:58', 0),
(6, '2', '2', '1', 'portfolio_images0-5fbf4e87a548a2020-11-26jpg.jpg_-_portfolio_images1-5fbf4e87a82b32020-11-26jpg.jpg_-_portfolio_images2-5fbf4e87aafcd2020-11-26jpg.jpg', '2', '2', '2', '2020-11-26 06:43:19', 0),
(7, '1', '1', '1', 'portfolio_images0-5fbf4ea56eec12020-11-26jpg.jpg_-_portfolio_images1-5fbf4ea5721502020-11-26jpg.jpg_-_portfolio_images2-5fbf4ea5754a82020-11-26jpg.jpg', '1', '1', '', '2020-11-26 06:43:49', 0),
(8, '1', '1', '1', 'portfolio_images0-5fbf4ebe316b42020-11-26jpg.jpg_-_portfolio_images1-5fbf4ebe34f122020-11-26jpg.jpg_-_portfolio_images2-5fbf4ebe387a12020-11-26jpg.jpg', '1', '1', '11', '2020-11-26 06:44:14', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner_pic`
--
ALTER TABLE `banner_pic`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `banner_pic`
--
ALTER TABLE `banner_pic`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
